-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 22, 2020 at 06:44 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `peternakan`
--

-- --------------------------------------------------------

--
-- Table structure for table `agenda`
--

CREATE TABLE `agenda` (
  `id` int(11) NOT NULL,
  `agenda` varchar(225) NOT NULL,
  `jadwal_mulai` date NOT NULL,
  `jadwal_selesai` date NOT NULL,
  `hari_mulai` varchar(15) NOT NULL,
  `hari_selesai` varchar(15) NOT NULL,
  `tanggal_mulai` varchar(15) NOT NULL,
  `tanggal_selesai` varchar(15) NOT NULL,
  `bulan_mulai` varchar(15) NOT NULL,
  `bulan_selesai` varchar(15) NOT NULL,
  `tahun_mulai` varchar(15) NOT NULL,
  `tahun_selesai` varchar(15) NOT NULL,
  `jam_mulai` varchar(15) NOT NULL,
  `jam_selesai` varchar(15) NOT NULL,
  `menit_mulai` varchar(15) NOT NULL,
  `menit_selesai` varchar(15) NOT NULL,
  `status` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `agenda`
--

INSERT INTO `agenda` (`id`, `agenda`, `jadwal_mulai`, `jadwal_selesai`, `hari_mulai`, `hari_selesai`, `tanggal_mulai`, `tanggal_selesai`, `bulan_mulai`, `bulan_selesai`, `tahun_mulai`, `tahun_selesai`, `jam_mulai`, `jam_selesai`, `menit_mulai`, `menit_selesai`, `status`) VALUES
(23, 'A', '2018-08-22', '2018-08-25', 'Rabu', 'Sabtu', '22', '25', '08', '08', '2018', '2018', '17', '17', '45', '46', ''),
(30, 'B', '2018-08-22', '2018-08-25', 'Rabu', 'Sabtu', '22', '25', '08', '08', '2018', '2018', '17', '18', '45', '46', ''),
(31, 'C', '2018-08-22', '2018-08-25', 'Rabu', 'Sabtu', '22', '25', '08', '08', '2018', '2018', '18', '18', '45', '46', ''),
(37, 'qwdwq', '2018-08-26', '2018-08-26', 'Minggu', 'Minggu', '26', '26', '08', '08', '2018', '2018', '11', '11', '35', '36', ''),
(38, 'C', '2018-08-25', '2018-08-29', 'Sabtu', 'Rabu', '25', '29', '08', '08', '2018', '2018', '12', '12', '27', '28', ''),
(39, 'DE', '2018-08-14', '2018-08-16', 'Selasa', 'Kamis', '14', '16', '08', '08', '2018', '2018', '12', '12', '51', '52', '');

-- --------------------------------------------------------

--
-- Table structure for table `atas`
--

CREATE TABLE `atas` (
  `id` int(5) NOT NULL,
  `Keterangan` varchar(222) NOT NULL,
  `judul` varchar(222) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `atas`
--

INSERT INTO `atas` (`id`, `Keterangan`, `judul`) VALUES
(16, 'hortik', 'b_hortikultura.jpeg'),
(17, 'b1', 'b_perkebunan.jpeg'),
(18, 'b2', 'b_sapra.jpeg'),
(19, 'b3', 'b_tangan.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `berita`
--

CREATE TABLE `berita` (
  `id` int(30) NOT NULL,
  `info` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `berita`
--

INSERT INTO `berita` (`id`, `info`) VALUES
(61, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau '),
(62, 'terwujudnya Pertanian dan Peternakan Riau yang Maju'),
(64, 'aku adalah anak gembala');

-- --------------------------------------------------------

--
-- Table structure for table `beritagabung`
--

CREATE TABLE `beritagabung` (
  `id` int(11) NOT NULL,
  `info` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `beritagabung`
--

INSERT INTO `beritagabung` (`id`, `info`) VALUES
(1, 'jurss. tez. zzz. zzz. info doang. mastin punya yang baru'),
(2, ''),
(3, ''),
(4, 'test'),
(5, 'EZ'),
(6, ''),
(7, 'test. EZ. EZ. EZ'),
(8, 'test. EZ. EZ. EZ. EZ'),
(9, 'test. EZ. EZ. EZ. EZ. TES EZ BANGET COKKKKKKK'),
(10, 'EZ. EZ. EZ. EZ. TES EZ BANGET COKKKKKKK'),
(11, 'EZ. EZ. EZ. TES EZ BANGET COKKKKKKK'),
(12, 'EZ. EZ. TES EZ BANGET COKKKKKKK'),
(13, 'EZ. TES EZ BANGET COKKKKKKK'),
(14, 'TES EZ BANGET COKKKKKKK'),
(15, 'TES EZ BANGET COKKKKKKK. tez EZ BANGET COK'),
(16, 'tez EZ BANGET COK'),
(17, 'tez EZ BANGET COK'),
(18, 'tez EZ BANGET COK'),
(19, 'tez EZ BANGET COK'),
(20, 'tez EZ BANGET COK'),
(21, 'tez EZ BANGET COK'),
(22, 'tez EZ BANGET COK'),
(23, 'tez EZ BANGET COK'),
(24, 'tez EZ BANGET COK'),
(25, 'tez EZ BANGET COK'),
(26, 'tez EZ BANGET COK'),
(27, 'tez EZ BANGET COK. '),
(28, 'tez EZ BANGET COK. '),
(29, 'tez EZ BANGET COK. '),
(30, 'tez EZ BANGET COK. '),
(31, ''),
(32, ''),
(33, '. tezz'),
(34, '. tezz'),
(35, '. tezz'),
(36, '. tezz'),
(37, '. tezz'),
(38, '. tezz'),
(39, '. tezz'),
(40, '. tezz'),
(41, '. tezz'),
(42, '. tezz'),
(43, '. tezz'),
(44, '. tezz'),
(45, '. tezz'),
(46, '. tezz'),
(47, '. tezz'),
(48, '. tezz'),
(49, '. tezz'),
(50, '. tezz'),
(51, '. tezz'),
(52, '. tezz'),
(53, '. tezz'),
(54, '. tezz'),
(55, '. tezz'),
(56, '. tezz'),
(57, '. tezz'),
(58, '. tezz'),
(59, '. tezz'),
(60, '. tezz'),
(61, '. tezz'),
(62, '. tezz'),
(63, '. tezz'),
(64, '. tezz'),
(65, '. tezz'),
(66, '. tezz'),
(67, '. tezz'),
(68, '. tezz'),
(69, '. tezz'),
(70, '. tezz'),
(71, '. tezz'),
(72, '. tezz'),
(73, '. tezz'),
(74, '. tezz'),
(75, '. tezz'),
(76, '. tezz'),
(77, '. tezz'),
(78, '. tezz'),
(79, '. tezz'),
(80, '. tezz'),
(81, '. tezz'),
(82, '. tezz'),
(83, '. tezz'),
(84, '. tezz'),
(85, '. tezz'),
(86, '. tezz'),
(87, '. tezz'),
(88, '. tezz'),
(89, '. tezz'),
(90, '. tezz'),
(91, '. tezz'),
(92, '. tezz'),
(93, '. tezz'),
(94, '. tezz'),
(95, ''),
(96, ''),
(97, ''),
(98, ''),
(99, ''),
(100, ''),
(101, ''),
(102, ''),
(103, ''),
(104, ''),
(105, ''),
(106, ''),
(107, ''),
(108, ''),
(109, ''),
(110, ''),
(111, ''),
(112, ''),
(113, ''),
(114, ''),
(115, ''),
(116, '. tezz'),
(117, '. tezz'),
(118, '. tezz'),
(119, '. tezz'),
(120, '. tezz'),
(121, '. tezz'),
(122, '. tezz'),
(123, '. tezz'),
(124, '. tezz'),
(125, '. tezz'),
(126, '. tezz'),
(127, '. tezz'),
(128, '. tezz'),
(129, '. tezz'),
(130, '. tezz'),
(131, '. tezz'),
(132, '. tezz'),
(133, '. tezz'),
(134, ''),
(135, ''),
(136, ''),
(137, ''),
(138, ''),
(139, ''),
(140, ''),
(141, ''),
(142, ''),
(143, ''),
(144, ''),
(145, ''),
(146, ''),
(147, ''),
(148, ''),
(149, ''),
(150, ''),
(151, ''),
(152, ''),
(153, ''),
(154, ''),
(155, '. tezz'),
(156, '. tezz'),
(157, '. tezz. TESt'),
(158, '. tezz. TESt'),
(159, '. tezz. TESt'),
(160, '. tezz. TESt'),
(161, ''),
(162, '. tezz. TESt. test. test. test. test. test'),
(163, '. tezz. TESt. test. test. test. test. test'),
(164, '. tezz. TESt. test. test. test. test. test'),
(165, '. tezz. TESt. test. test. test. test. test'),
(166, '&nbsp&nbsp| &nbsp&nbsptezz&nbsp&nbsp| &nbsp&nbspTESt&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(167, '&nbsp&nbsp| &nbsp&nbsptezz&nbsp&nbsp| &nbsp&nbspTESt&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(168, '&nbsp&nbsp| &nbsp&nbsptezz&nbsp&nbsp| &nbsp&nbspTESt&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(169, '&nbsp&nbsp| &nbsp&nbsptezz&nbsp&nbsp| &nbsp&nbspTESt&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(170, '&nbsp&nbsp| &nbsp&nbsptezz&nbsp&nbsp| &nbsp&nbspTESt&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(171, '&nbsp&nbsp| &nbsp&nbsptezz&nbsp&nbsp| &nbsp&nbspTESt&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(172, '&nbsp&nbsp| &nbsp&nbspTESt&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(173, '&nbsp&nbsp| &nbsp&nbspTESt&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(174, '&nbsp&nbsp| &nbsp&nbspTESt&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(175, 'TESt&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(176, 'TESt&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(177, 'TESt&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(178, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(179, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(180, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(181, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(182, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(183, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(184, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(185, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(186, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(187, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(188, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(189, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(190, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(191, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(192, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(193, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(194, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(195, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(196, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(197, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(198, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(199, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(200, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(201, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(202, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(203, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(204, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(205, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(206, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(207, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(208, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(209, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(210, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(211, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(212, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(213, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(214, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(215, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(216, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(217, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(218, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(219, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(220, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(221, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(222, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(223, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(224, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(225, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(226, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(227, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(228, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(229, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(230, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(231, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(232, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(233, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(234, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(235, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(236, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(237, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(238, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(239, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(240, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(241, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(242, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(243, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(244, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(245, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(246, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(247, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(248, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(249, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(250, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(251, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(252, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(253, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(254, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(255, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(256, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(257, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(258, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(259, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(260, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(261, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(262, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(263, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(264, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(265, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(266, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(267, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(268, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(269, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(270, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(271, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(272, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(273, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(274, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(275, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(276, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(277, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(278, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(279, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(280, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(281, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(282, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(283, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(284, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(285, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(286, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(287, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(288, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(289, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(290, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(291, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(292, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(293, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(294, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(295, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(296, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(297, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(298, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(299, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(300, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(301, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(302, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(303, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(304, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(305, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(306, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(307, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(308, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(309, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(310, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(311, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(312, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(313, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(314, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(315, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(316, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(317, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(318, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(319, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(320, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(321, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(322, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(323, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(324, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(325, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(326, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(327, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(328, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(329, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(330, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(331, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(332, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(333, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(334, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(335, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(336, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(337, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(338, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(339, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(340, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(341, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(342, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(343, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(344, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(345, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(346, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(347, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(348, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(349, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(350, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(351, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(352, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(353, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(354, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(355, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(356, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(357, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(358, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(359, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(360, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(361, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(362, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(363, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(364, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(365, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(366, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(367, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(368, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(369, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(370, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(371, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(372, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(373, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(374, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(375, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(376, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(377, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(378, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(379, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(380, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(381, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(382, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(383, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(384, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(385, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(386, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(387, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(388, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(389, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(390, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(391, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(392, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(393, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(394, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(395, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(396, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(397, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(398, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(399, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(400, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(401, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(402, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(403, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(404, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(405, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(406, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(407, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(408, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(409, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(410, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(411, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(412, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(413, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(414, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(415, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(416, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(417, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(418, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(419, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(420, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(421, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(422, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(423, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(424, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(425, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(426, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(427, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(428, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(429, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(430, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(431, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(432, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(433, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(434, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(435, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(436, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(437, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(438, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(439, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(440, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(441, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(442, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(443, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(444, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(445, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(446, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(447, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(448, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(449, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(450, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(451, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(452, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(453, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(454, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(455, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(456, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(457, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(458, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(459, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(460, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(461, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(462, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(463, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(464, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(465, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(466, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(467, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(468, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(469, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(470, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(471, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(472, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(473, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(474, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(475, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(476, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(477, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(478, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(479, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(480, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(481, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(482, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(483, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(484, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(485, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(486, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(487, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(488, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(489, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(490, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(491, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(492, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(493, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(494, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(495, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(496, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(497, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(498, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(499, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(500, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(501, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(502, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(503, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(504, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(505, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(506, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(507, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(508, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(509, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(510, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(511, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(512, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(513, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(514, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(515, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(516, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(517, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(518, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(519, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(520, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(521, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(522, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(523, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(524, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(525, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(526, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(527, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(528, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(529, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(530, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(531, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(532, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(533, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(534, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(535, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(536, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(537, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(538, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(539, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(540, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(541, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(542, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(543, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(544, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(545, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(546, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(547, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(548, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(549, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(550, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(551, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(552, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(553, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(554, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(555, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(556, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(557, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(558, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(559, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(560, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(561, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(562, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(563, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(564, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(565, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(566, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(567, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(568, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(569, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(570, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(571, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(572, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(573, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(574, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(575, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(576, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(577, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(578, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(579, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(580, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(581, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(582, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(583, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(584, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(585, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(586, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(587, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(588, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(589, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(590, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(591, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(592, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(593, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(594, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(595, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(596, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(597, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(598, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(599, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(600, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(601, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(602, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(603, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(604, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(605, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(606, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(607, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(608, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(609, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(610, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(611, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(612, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(613, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(614, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(615, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(616, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(617, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(618, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(619, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(620, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(621, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(622, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(623, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(624, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(625, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(626, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(627, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(628, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(629, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(630, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(631, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(632, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(633, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(634, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(635, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(636, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(637, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(638, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(639, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(640, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(641, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(642, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(643, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(644, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(645, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(646, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(647, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(648, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(649, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(650, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(651, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(652, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(653, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(654, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(655, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(656, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(657, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(658, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(659, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(660, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(661, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(662, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(663, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(664, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(665, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(666, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(667, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(668, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(669, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(670, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(671, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(672, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(673, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(674, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(675, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(676, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(677, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(678, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(679, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(680, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(681, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(682, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(683, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(684, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(685, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(686, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(687, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(688, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(689, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(690, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(691, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(692, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(693, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(694, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(695, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(696, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(697, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(698, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(699, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(700, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(701, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(702, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(703, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(704, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(705, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(706, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(707, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(708, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(709, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(710, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(711, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(712, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(713, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(714, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(715, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(716, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(717, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(718, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(719, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(720, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(721, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(722, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(723, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(724, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(725, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(726, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(727, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(728, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(729, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(730, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(731, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(732, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(733, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(734, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(735, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(736, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(737, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(738, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(739, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(740, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(741, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(742, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(743, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(744, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(745, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(746, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(747, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(748, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(749, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(750, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(751, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(752, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(753, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(754, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(755, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(756, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(757, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(758, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(759, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(760, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(761, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(762, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(763, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(764, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(765, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(766, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(767, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(768, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(769, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(770, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(771, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(772, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(773, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(774, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(775, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(776, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(777, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(778, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(779, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(780, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(781, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(782, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(783, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(784, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(785, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(786, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(787, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(788, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(789, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(790, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(791, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(792, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(793, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(794, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(795, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(796, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(797, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(798, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(799, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(800, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(801, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(802, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(803, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(804, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(805, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(806, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(807, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(808, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(809, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(810, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(811, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(812, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(813, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(814, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(815, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(816, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(817, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(818, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(819, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(820, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(821, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(822, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(823, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(824, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(825, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(826, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(827, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(828, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(829, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(830, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(831, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(832, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(833, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(834, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(835, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(836, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(837, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(838, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(839, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(840, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(841, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(842, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(843, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(844, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(845, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(846, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(847, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(848, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(849, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(850, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(851, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(852, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(853, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(854, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(855, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(856, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(857, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(858, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(859, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(860, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(861, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(862, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(863, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(864, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(865, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(866, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(867, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(868, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(869, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(870, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(871, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(872, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(873, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(874, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest');
INSERT INTO `beritagabung` (`id`, `info`) VALUES
(875, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(876, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(877, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(878, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(879, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(880, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(881, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(882, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(883, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(884, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(885, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(886, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(887, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(888, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(889, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(890, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(891, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(892, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(893, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(894, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(895, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(896, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(897, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(898, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(899, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(900, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(901, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(902, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(903, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(904, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(905, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(906, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(907, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(908, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(909, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(910, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(911, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(912, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbsptest'),
(913, 'test&nbsp&nbsp| &nbsp&nbsptest'),
(914, 'test&nbsp&nbsp| &nbsp&nbsptest'),
(915, 'test&nbsp&nbsp| &nbsp&nbsptest'),
(916, 'test&nbsp&nbsp| &nbsp&nbsptest'),
(917, 'test&nbsp&nbsp| &nbsp&nbsptest'),
(918, 'test&nbsp&nbsp| &nbsp&nbsptest'),
(919, 'test&nbsp&nbsp| &nbsp&nbsptest'),
(920, 'test&nbsp&nbsp| &nbsp&nbsptest'),
(921, 'test&nbsp&nbsp| &nbsp&nbsptest'),
(922, 'test&nbsp&nbsp| &nbsp&nbsptest'),
(923, 'test&nbsp&nbsp| &nbsp&nbsptest'),
(924, 'test&nbsp&nbsp| &nbsp&nbsptest'),
(925, 'test&nbsp&nbsp| &nbsp&nbsptest'),
(926, 'test&nbsp&nbsp| &nbsp&nbsptest'),
(927, 'test&nbsp&nbsp| &nbsp&nbsptest'),
(928, 'test&nbsp&nbsp| &nbsp&nbsptest'),
(929, 'test&nbsp&nbsp| &nbsp&nbsptest'),
(930, 'test&nbsp&nbsp| &nbsp&nbsptest'),
(931, 'test&nbsp&nbsp| &nbsp&nbsptest'),
(932, 'test&nbsp&nbsp| &nbsp&nbsptest'),
(933, 'test&nbsp&nbsp| &nbsp&nbsptest'),
(934, 'test&nbsp&nbsp| &nbsp&nbsptest'),
(935, 'test&nbsp&nbsp| &nbsp&nbsptest'),
(936, 'test&nbsp&nbsp| &nbsp&nbsptest'),
(937, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbspDinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau '),
(938, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbspDinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau '),
(939, 'test&nbsp&nbsp| &nbsp&nbsptest&nbsp&nbsp| &nbsp&nbspDinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau '),
(940, 'test&nbsp&nbsp| &nbsp&nbspDinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau '),
(941, 'test&nbsp&nbsp| &nbsp&nbspDinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau '),
(942, 'test&nbsp&nbsp| &nbsp&nbspDinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau '),
(943, 'test&nbsp&nbsp| &nbsp&nbspDinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju,'),
(944, 'test&nbsp&nbsp| &nbsp&nbspDinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju,'),
(945, 'test&nbsp&nbsp| &nbsp&nbspDinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju,'),
(946, 'test&nbsp&nbsp| &nbsp&nbspDinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju,'),
(947, 'test&nbsp&nbsp| &nbsp&nbspDinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju,'),
(948, 'test&nbsp&nbsp| &nbsp&nbspDinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju,'),
(949, 'test&nbsp&nbsp| &nbsp&nbspDinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju'),
(950, 'test&nbsp&nbsp| &nbsp&nbspDinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju'),
(951, 'test&nbsp&nbsp| &nbsp&nbspDinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju'),
(952, 'test&nbsp&nbsp| &nbsp&nbspDinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(953, 'test&nbsp&nbsp| &nbsp&nbspDinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(954, 'test&nbsp&nbsp| &nbsp&nbspDinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(955, 'test&nbsp&nbsp| &nbsp&nbspDinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(956, 'test&nbsp&nbsp| &nbsp&nbspDinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(957, 'test&nbsp&nbsp| &nbsp&nbspDinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(958, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(959, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(960, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(961, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(962, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(963, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(964, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(965, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(966, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(967, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(968, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(969, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(970, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(971, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(972, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(973, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(974, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(975, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(976, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(977, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(978, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(979, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(980, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(981, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(982, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(983, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(984, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(985, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(986, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(987, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(988, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(989, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(990, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(991, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(992, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(993, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(994, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(995, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(996, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(997, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(998, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(999, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1000, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1001, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1002, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1003, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1004, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1005, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1006, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1007, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1008, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1009, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1010, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1011, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1012, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1013, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1014, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1015, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1016, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1017, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1018, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1019, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1020, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1021, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1022, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1023, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1024, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1025, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1026, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1027, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1028, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1029, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1030, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1031, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1032, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1033, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1034, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1035, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1036, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1037, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1038, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1039, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1040, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1041, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1042, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1043, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1044, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1045, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1046, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1047, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1048, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1049, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1050, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1051, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1052, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1053, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1054, ''),
(1055, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1056, ''),
(1057, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1058, ''),
(1059, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspMenuju Petani dan Peternak yang Sejahtera dengan Dukungan Aparatur yang Andal'),
(1060, ''),
(1061, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbsperwujudnya Pertanian dan Peternakan Riau yang Maju'),
(1062, ''),
(1063, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju'),
(1064, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju'),
(1065, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju'),
(1066, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju'),
(1067, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju'),
(1068, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju'),
(1069, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju'),
(1070, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju'),
(1071, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju'),
(1072, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju'),
(1073, ''),
(1074, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju'),
(1075, ''),
(1076, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju'),
(1077, ''),
(1078, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju'),
(1079, ''),
(1080, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju'),
(1081, ''),
(1082, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju'),
(1083, ''),
(1084, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju'),
(1085, ''),
(1086, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju'),
(1087, ''),
(1088, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1089, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1090, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1091, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1092, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1093, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1094, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1095, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1096, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1097, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1098, ''),
(1099, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1100, ''),
(1101, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1102, ''),
(1103, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1104, ''),
(1105, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1106, ''),
(1107, ''),
(1108, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1109, ''),
(1110, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1111, ''),
(1112, ''),
(1113, ''),
(1114, ''),
(1115, ''),
(1116, ''),
(1117, ''),
(1118, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1119, ''),
(1120, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1121, ''),
(1122, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1123, ''),
(1124, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1125, ''),
(1126, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1127, ''),
(1128, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1129, ''),
(1130, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1131, ''),
(1132, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1133, ''),
(1134, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1135, ''),
(1136, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1137, ''),
(1138, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1139, ''),
(1140, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1141, ''),
(1142, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1143, ''),
(1144, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1145, ''),
(1146, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1147, ''),
(1148, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1149, ''),
(1150, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1151, ''),
(1152, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1153, ''),
(1154, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1155, ''),
(1156, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1157, ''),
(1158, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1159, ''),
(1160, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1161, ''),
(1162, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1163, ''),
(1164, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1165, ''),
(1166, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1167, ''),
(1168, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1169, ''),
(1170, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1171, ''),
(1172, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1173, ''),
(1174, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1175, ''),
(1176, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1177, ''),
(1178, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1179, ''),
(1180, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1181, ''),
(1182, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1183, ''),
(1184, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1185, ''),
(1186, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1187, ''),
(1188, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1189, ''),
(1190, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1191, ''),
(1192, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1193, ''),
(1194, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1195, ''),
(1196, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1197, ''),
(1198, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1199, ''),
(1200, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1201, ''),
(1202, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1203, ''),
(1204, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1205, ''),
(1206, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1207, ''),
(1208, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1209, ''),
(1210, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1211, ''),
(1212, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1213, ''),
(1214, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1215, ''),
(1216, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1217, ''),
(1218, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1219, ''),
(1220, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1221, ''),
(1222, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1223, ''),
(1224, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1225, ''),
(1226, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1227, ''),
(1228, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1229, ''),
(1230, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1231, ''),
(1232, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1233, ''),
(1234, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1235, ''),
(1236, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1237, ''),
(1238, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1239, ''),
(1240, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1241, ''),
(1242, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1243, ''),
(1244, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1245, ''),
(1246, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1247, ''),
(1248, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1249, ''),
(1250, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1251, ''),
(1252, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1253, ''),
(1254, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1255, ''),
(1256, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1257, ''),
(1258, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1259, ''),
(1260, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1261, ''),
(1262, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1263, ''),
(1264, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1265, ''),
(1266, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1267, ''),
(1268, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1269, ''),
(1270, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1271, ''),
(1272, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1273, ''),
(1274, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1275, ''),
(1276, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1277, ''),
(1278, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1279, ''),
(1280, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1281, ''),
(1282, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1283, ''),
(1284, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp');
INSERT INTO `beritagabung` (`id`, `info`) VALUES
(1285, ''),
(1286, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1287, ''),
(1288, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1289, ''),
(1290, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1291, ''),
(1292, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1293, ''),
(1294, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1295, ''),
(1296, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1297, ''),
(1298, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1299, ''),
(1300, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1301, ''),
(1302, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1303, ''),
(1304, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1305, ''),
(1306, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1307, ''),
(1308, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1309, ''),
(1310, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1311, ''),
(1312, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1313, ''),
(1314, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1315, ''),
(1316, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1317, ''),
(1318, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1319, ''),
(1320, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1321, ''),
(1322, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1323, ''),
(1324, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1325, ''),
(1326, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1327, ''),
(1328, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1329, ''),
(1330, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1331, ''),
(1332, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1333, ''),
(1334, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1335, ''),
(1336, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1337, ''),
(1338, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1339, ''),
(1340, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1341, ''),
(1342, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1343, ''),
(1344, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1345, ''),
(1346, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1347, ''),
(1348, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1349, ''),
(1350, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1351, ''),
(1352, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1353, ''),
(1354, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1355, ''),
(1356, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1357, ''),
(1358, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1359, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1360, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1361, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1362, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1363, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1364, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1365, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1366, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1367, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1368, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1369, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1370, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1371, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1372, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1373, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1374, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1375, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1376, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1377, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1378, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1379, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1380, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1381, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1382, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1383, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1384, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1385, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1386, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1387, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1388, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1389, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1390, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1391, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1392, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1393, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1394, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1395, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1396, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1397, '&nbsp&nbsp| &nbsp&nbsp&nbsp&nbsp| &nbsp&nbsp'),
(1398, ''),
(1399, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1400, ''),
(1401, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1402, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1403, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1404, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1405, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1406, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1407, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1408, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1409, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1410, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1411, ''),
(1412, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1413, ''),
(1414, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1415, ''),
(1416, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1417, ''),
(1418, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1419, ''),
(1420, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1421, ''),
(1422, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1423, ''),
(1424, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1425, ''),
(1426, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1427, ''),
(1428, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1429, ''),
(1430, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1431, ''),
(1432, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1433, ''),
(1434, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1435, ''),
(1436, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1437, ''),
(1438, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1439, ''),
(1440, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1441, ''),
(1442, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1443, ''),
(1444, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1445, ''),
(1446, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1447, ''),
(1448, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1449, ''),
(1450, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1451, ''),
(1452, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1453, ''),
(1454, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1455, ''),
(1456, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1457, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1458, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1459, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1460, ''),
(1461, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1462, ''),
(1463, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1464, ''),
(1465, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1466, ''),
(1467, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1468, ''),
(1469, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1470, ''),
(1471, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1472, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1473, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1474, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1475, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1476, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1477, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1478, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1479, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1480, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1481, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1482, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1483, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1484, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1485, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1486, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1487, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1488, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1489, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1490, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1491, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1492, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1493, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1494, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1495, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1496, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1497, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1498, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1499, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1500, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1501, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1502, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1503, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1504, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1505, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1506, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1507, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1508, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1509, ''),
(1510, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1511, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1512, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1513, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1514, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1515, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala'),
(1516, 'Dinas Tanaman Pangan Hortikultura dan Perkebunan Provinsi Riau &nbsp&nbsp| &nbsp&nbspterwujudnya Pertanian dan Peternakan Riau yang Maju&nbsp&nbsp| &nbsp&nbspaku adalah anak gembala');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `id` int(2) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`id`, `name`) VALUES
(1, 'PT. Altov Tech22');

-- --------------------------------------------------------

--
-- Table structure for table `covid`
--

CREATE TABLE `covid` (
  `id` int(1) NOT NULL,
  `suspek` bigint(20) NOT NULL,
  `konfirmasi` bigint(40) NOT NULL,
  `isolasi` bigint(40) NOT NULL,
  `rawat` bigint(40) NOT NULL,
  `sembuh` bigint(40) NOT NULL,
  `wafat` bigint(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `covid`
--

INSERT INTO `covid` (`id`, `suspek`, `konfirmasi`, `isolasi`, `rawat`, `sembuh`, `wafat`) VALUES
(1, 518484848, 5125521440, 414412224, 994214, 370379214, 8568214);

-- --------------------------------------------------------

--
-- Table structure for table `covidstyle`
--

CREATE TABLE `covidstyle` (
  `id` int(1) NOT NULL,
  `suspek` varchar(200) NOT NULL,
  `konfirmasi` varchar(200) NOT NULL,
  `isolasi` varchar(200) NOT NULL,
  `rawat` varchar(200) NOT NULL,
  `sembuh` varchar(200) NOT NULL,
  `wafat` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `covidstyle`
--

INSERT INTO `covidstyle` (`id`, `suspek`, `konfirmasi`, `isolasi`, `rawat`, `sembuh`, `wafat`) VALUES
(1, 'rgba(84,255,175,0.38)', 'rgba(0,0,0,0)', 'rgba(0,0,0,0)', 'rgba(0,0,0,0)', 'rgba(0,0,0,0)', 'rgba(0,0,0,0)'),
(2, 'rgb(167,0,0)', 'rgb(255,135,227)', 'rgb(0,123,255)', 'rgb(23,162,184)', 'rgb(40,167,69)', 'rgb(220,53,69)');

-- --------------------------------------------------------

--
-- Table structure for table `kanan_bawah`
--

CREATE TABLE `kanan_bawah` (
  `id` int(5) NOT NULL,
  `Keterangan` varchar(222) NOT NULL,
  `judul` varchar(222) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kanan_bawah`
--

INSERT INTO `kanan_bawah` (`id`, `Keterangan`, `judul`) VALUES
(6, 'c', 'cintai.jpeg'),
(7, 'pan', 'panen.jpeg'),
(8, 'pe', 'pedoman.jpeg'),
(9, 'tan', 'tanah.jpeg'),
(10, 'tatan', 'tantan.jpeg'),
(11, 'ww', '750xauto-nama-panjang-orang-ini-bikin-kamu-keseleo-lidah-tirukan-kalau-bisa-161205g.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `kiri_atas`
--

CREATE TABLE `kiri_atas` (
  `id` int(5) NOT NULL,
  `Keterangan` varchar(222) NOT NULL,
  `judul` varchar(222) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kiri_atas`
--

INSERT INTO `kiri_atas` (`id`, `Keterangan`, `judul`) VALUES
(5, 'ag', 'agro.jpeg'),
(6, 'ag2', 'agro18.jpeg'),
(7, 'hor', 'hortikult.jpeg'),
(8, 'stat', 'statis.jpeg'),
(9, 'ff', '750xauto-nama-panjang-orang-ini-bikin-kamu-keseleo-lidah-tirukan-kalau-bisa-161205g.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `kiri_bawah`
--

CREATE TABLE `kiri_bawah` (
  `id` int(5) NOT NULL,
  `Keterangan` varchar(222) NOT NULL,
  `judul` varchar(222) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kiri_bawah`
--

INSERT INTO `kiri_bawah` (`id`, `Keterangan`, `judul`) VALUES
(12, 'porgan.jpeg', 'porgan.jpeg'),
(13, 'pulmi', 'pulmi.jpeg'),
(14, 'pupat', 'pupat.jpeg'),
(15, 'pupuk', 'pupuk.jpeg'),
(16, 'aa', '750xauto-nama-panjang-orang-ini-bikin-kamu-keseleo-lidah-tirukan-kalau-bisa-161205g.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `konfigurasi`
--

CREATE TABLE `konfigurasi` (
  `id` int(11) NOT NULL,
  `timeslide` int(15) NOT NULL DEFAULT 5000,
  `jarak` int(1) NOT NULL DEFAULT 1,
  `color1` varchar(11) NOT NULL,
  `color2` varchar(20) NOT NULL,
  `clockcolor` varchar(20) NOT NULL,
  `textcolor` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `konfigurasi`
--

INSERT INTO `konfigurasi` (`id`, `timeslide`, `jarak`, `color1`, `color2`, `clockcolor`, `textcolor`) VALUES
(1, 5000, 1, '3d3d3d', '3d3d3d', '3d3d3d', 'ffffff');

-- --------------------------------------------------------

--
-- Table structure for table `main`
--

CREATE TABLE `main` (
  `id` int(5) NOT NULL,
  `flip_clock_1` varchar(55) NOT NULL,
  `flip_clock_2` varchar(55) NOT NULL,
  `flip_clock_3` varchar(55) NOT NULL,
  `flip_clock_4` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `main`
--

INSERT INTO `main` (`id`, `flip_clock_1`, `flip_clock_2`, `flip_clock_3`, `flip_clock_4`) VALUES
(1, '#fff', '#000', '#000', '0');

-- --------------------------------------------------------

--
-- Table structure for table `pegawai`
--

CREATE TABLE `pegawai` (
  `id` int(5) NOT NULL,
  `Nama` varchar(55) NOT NULL,
  `Jabatan` varchar(55) NOT NULL,
  `Nomor` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pegawai`
--

INSERT INTO `pegawai` (`id`, `Nama`, `Jabatan`, `Nomor`) VALUES
(0, 'Abcd, M.Sc., S.T.', 'Security', '54232');

-- --------------------------------------------------------

--
-- Table structure for table `ref`
--

CREATE TABLE `ref` (
  `id` int(11) NOT NULL,
  `refresh` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ref`
--

INSERT INTO `ref` (`id`, `refresh`) VALUES
(1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `id` int(30) NOT NULL,
  `keterangan` varchar(200) NOT NULL,
  `judul` varchar(200) NOT NULL,
  `judul_konversi` varchar(155) NOT NULL,
  `tipe` int(15) DEFAULT NULL,
  `durasi` int(22) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`id`, `keterangan`, `judul`, `judul_konversi`, `tipe`, `durasi`) VALUES
(12, '', 'Dream_lake_1.mp4', 'Dream_lake_1.png', 2, 8406),
(14, 'AA', 'imageonline-co-placeholder-image.mp4', 'imageonline-co-placeholder-image.jpg', 1, 2000);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(31) NOT NULL,
  `nama` varchar(66) NOT NULL,
  `username` varchar(66) NOT NULL,
  `password` varchar(66) NOT NULL,
  `user_type` varchar(66) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `nama`, `username`, `password`, `user_type`) VALUES
(1, 'admin', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agenda`
--
ALTER TABLE `agenda`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `atas`
--
ALTER TABLE `atas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `berita`
--
ALTER TABLE `berita`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `beritagabung`
--
ALTER TABLE `beritagabung`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `covid`
--
ALTER TABLE `covid`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `covidstyle`
--
ALTER TABLE `covidstyle`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kanan_bawah`
--
ALTER TABLE `kanan_bawah`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kiri_atas`
--
ALTER TABLE `kiri_atas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kiri_bawah`
--
ALTER TABLE `kiri_bawah`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `konfigurasi`
--
ALTER TABLE `konfigurasi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `main`
--
ALTER TABLE `main`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ref`
--
ALTER TABLE `ref`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `agenda`
--
ALTER TABLE `agenda`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `atas`
--
ALTER TABLE `atas`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `berita`
--
ALTER TABLE `berita`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `beritagabung`
--
ALTER TABLE `beritagabung`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1517;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `kanan_bawah`
--
ALTER TABLE `kanan_bawah`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `kiri_atas`
--
ALTER TABLE `kiri_atas`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `kiri_bawah`
--
ALTER TABLE `kiri_bawah`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `ref`
--
ALTER TABLE `ref`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
