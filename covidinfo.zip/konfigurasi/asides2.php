<style>
	body {
		text-align: center;
	}
</style>
<aside class="sidebar-left-collapse">
	<img style="width:5vw" src="../img/riau.png"></img>
	<div class="sidebar-links">
		<div class="link-blue">
			<a href="#">
				<i class="fa fa-clone"></i>Slider
			</a>
			<ul class="sub-links">
				<li><a href="slider1.php">Slider Utama</a></li>
			</ul>
		</div>
		<div class="link-red selected">
			<a href="#">
				<i class="fa fa-edit"></i>Berita
			</a>
			<ul class="sub-links">
				<li><a href="text.php">Running Text</a></li>
			</ul>
		</div>
		<div class="link-green">
			<a href="#">
				<i class="fa fa-cogs"></i>General
			</a>
			<ul class="sub-links">
				<li><a href="clock/clock.php">Color Panel</a></li>
			</ul>
		</div>
		<div class="link-yellow">
			<a href="refresh.php">
				<i class="fa fa-check"></i> <span>Apply changed</span> </i>
			</a>
		</div>
	</div>
</aside>