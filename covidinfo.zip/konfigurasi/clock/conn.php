<?php
 $con = mysqli_connect('localhost','root','','peternakan') OR die(mysql_error());
?>
