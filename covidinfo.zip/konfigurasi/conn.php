<?php
 $con = mysqli_connect('localhost','root','','peternakan');
?>