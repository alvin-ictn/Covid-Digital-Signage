<script>
	$(function() {

		var links = $('.sidebar-links > div');

		links.on('click', function() {

			links.removeClass('selected');
			$(this).addClass('selected');

		});
	});
</script>
<script src="assets/js/bootstrap.js"></script>