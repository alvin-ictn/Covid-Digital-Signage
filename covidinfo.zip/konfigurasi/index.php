<html>
<?php
include "conn.php";?>
<head>
	<?php include 'head.php'; ?>
</head>
<?php include 'control.php'; ?>

<body>
	<?php include 'asides.php'; ?>
	<div class="main-content">
		<div class="menu">
			<img class="arrow left" src="assets/images/demo-arrow-left.png" alt="arrow" height="120">
			<img class="arrow up" src="assets/images/demo-arrow-up.png" alt="arrow" height="150">
		</div>
	</div>
	<?php include 'foot.php'; ?>
</body>

</html>