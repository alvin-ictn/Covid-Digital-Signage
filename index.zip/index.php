<?php
include './conn.php';?>
<!doctype html>
<html><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Carlos Alvarez - Alvarez.is">
   <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> -->
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="css/mdb.min.css" rel="stylesheet">
    <!-- Your custom styles (optional) -->
    <link href="css/style.css" rel="stylesheet">

    <!-- Le styles -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/css/maincsseditet6june.css" rel="stylesheet">
    <link href="assets/css/font-style.css" rel="stylesheet">
    <link href="assets/css/flexslider.css" rel="stylesheet">
<!---------- CAROUSEL SPECIAL ---------->
<script type="text/javascript" src="car/jquery.min.js"></script>
<script type="text/javascript" src="car/bootstrap.min.js"></script>
<style type="text/css">
    @import url('car/bootstrap-combined.min.css');

#myCarousel {
  margin-top: 0px;
  display:flex;
  align-items:center;
  justify-content:center;
}

.carousel-linked-nav,
.item img {
  display: block; 
  margin: 0 auto;
}

.carousel-linked-nav {
  width: 120px;
  margin-bottom: 20px;   
}

  </style>
<link rel="stylesheet" href="compiled/flipclock.css">
<script src="compiled/flipclock.js"></script>
<script type="text/javascript">
$(window).load(function(){
var t;
var start = $('#myCarousel').find('.active').attr('data-interval');
t = setTimeout("$('#myCarousel').carousel({interval: 1000});", start-1000);

$('#myCarousel').on('slid.bs.carousel', function () {  
     clearTimeout(t);  
     var duration = $(this).find('.active').attr('data-interval');
    
     $('#myCarousel').carousel('pause');
     t = setTimeout("$('#myCarousel').carousel();", duration-1000);
})

$('.carousel-control.right').on('click', function(){
    clearTimeout(t);   
});

$('.carousel-control.left').on('click', function(){
    clearTimeout(t);   
});

});
</script>
<script type="text/javascript">
$(window).load(function(){
var t;
var start = $('#myCarousel2').find('.active').attr('data-interval');
t = setTimeout("$('#myCarousel2').carousel({interval: 1000});", start-1000);

$('#myCarousel2').on('slid.bs.carousel', function () {  
     clearTimeout(t);  
     var duration = $(this).find('.active').attr('data-interval');
    
     $('#myCarousel2').carousel('pause');
     t = setTimeout("$('#myCarousel2').carousel();", duration-1000);
})

$('.carousel-control.right').on('click', function(){
    clearTimeout(t);   
});

$('.carousel-control.left').on('click', function(){
    clearTimeout(t);   
});

});
</script>
<script type="text/javascript">
$(window).load(function(){
var t;
var start = $('#myCarousel3').find('.active').attr('data-interval');
t = setTimeout("$('#myCarousel3').carousel({interval: 1000});", start-1000);

$('#myCarousel3').on('slid.bs.carousel', function () {  
     clearTimeout(t);  
     var duration = $(this).find('.active').attr('data-interval');
    
     $('#myCarousel3').carousel('pause');
     t = setTimeout("$('#myCarousel3').carousel();", duration-1000);
})

$('.carousel-control.right').on('click', function(){
    clearTimeout(t);   
});

$('.carousel-control.left').on('click', function(){
    clearTimeout(t);   
});

});
</script>
<script type="text/javascript">
$(window).load(function(){
var t;
var start = $('#myCarousel4').find('.active').attr('data-interval');
t = setTimeout("$('#myCarousel4').carousel({interval: 1000});", start-1000);

$('#myCarousel4').on('slid.bs.carousel', function () {  
     clearTimeout(t);  
     var duration = $(this).find('.active').attr('data-interval');
    
     $('#myCarousel4').carousel('pause');
     t = setTimeout("$('#myCarousel4').carousel();", duration-1000);
})

$('.carousel-control.right').on('click', function(){
    clearTimeout(t);   
});

$('.carousel-control.left').on('click', function(){
    clearTimeout(t);   
});

});
</script>
<script type="text/javascript">
$(window).load(function(){
var t;
var start = $('#myCarousel5').find('.active').attr('data-interval');
t = setTimeout("$('#myCarousel5').carousel({interval: 1000});", start-1000);

$('#myCarousel5').on('slid.bs.carousel', function () {  
     clearTimeout(t);  
     var duration = $(this).find('.active').attr('data-interval');
    
     $('#myCarousel5').carousel('pause');
     t = setTimeout("$('#myCarousel5').carousel();", duration-1000);
})

$('.carousel-control.right').on('click', function(){
    clearTimeout(t);   
});

$('.carousel-control.left').on('click', function(){
    clearTimeout(t);   
});

});
</script>
<!------END CAR----->
    <style>
	div.zoomed { 
    zoom: 3; 
    -moz-transform: scale(3); 
    -moz-transform-origin: 0 0;
} </style>
	
    <style type="text/css">
      body {
        padding-top: 5px;
      }
    </style>

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <!-- Le fav and touch icons -->
    <link rel="shortcut icon" href="assets/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">

  	<!-- Google Fonts call. Font Used Open Sans & Raleway
	<link href="http://fonts.googleapis.com/css?family=Raleway:400,300" rel="stylesheet" type="text/css">
  	<link href="http://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet" type="text/css"> -->

<script type="text/javascript">
$(document).ready(function () {

    $("#btn-blog-next").click(function () {
      $('#blogCarousel').carousel('next')
    });
     $("#btn-blog-prev").click(function () {
      $('#blogCarousel').carousel('prev')
    });

     $("#btn-client-next").click(function () {
      $('#clientCarousel').carousel('next')
    });
     $("#btn-client-prev").click(function () {
      $('#clientCarousel').carousel('prev')
    });
    
});

 

</script>

<style>
html,body{ margin:0; padding:0; height:100%; width:100%; }
#full-size{
  height:100%;
  width:100%;
  overflow:hidden; /* or overflow:auto; if you want scrollbars */
}</style>
    
  </head>

  <?php $datamain=mysqli_fetch_array(mysqli_query($con, "SELECT * FROM `konfigurasi`"));?>
<body style="background: #<?php echo $datamain[3]?>">
	<style>
		.video-carousel-example {
		}
		​.img{
		float:right;
		height:20vh;
		}​
	</style>
<div style="width:100%;height: 100vh;  position: absolute; top: 0; left: 0;">	
	<div class="section-top col-sm-3 col-lg-3" style="<?php if($datamain[2]==1){ ?>padding-top:0px;padding-left:0px;padding-right:0px;padding-bottom:0px;<?php 	}else{}?>">
		<div class="topdash-unit" style="padding-bottom:0px;border-radius: 0px 0px 0px 0px;  background-color: #<?php echo $datamain[4]?>; <?php if($datamain[2]==1){
		?>margin-top:0px;margin-left:0px;margin-right:0px;margin-bottom:0px;<?php 	}else{}?>">
			<div class="col-sm-6 col-lg-6" style="padding-left:0px;height:100%;width:auto;">
			<img style="max-height: 100%;margin-top:-1px;margin-left:-1px;"  src="gambar/riau.png"></img>
			</div>
				<div class="col-sm-2-col-lg-2" style="padding-top:10px">
					<span style="font-size:20px;><center style="align:center">DINAS<br>TPH & PERKEBUNAN<br>PROVINSI RIAU</center></span>
				</div>
		</div>
	</div>
<style>

#topdash-unit img{height:100%;width:100%;}
</style>
	<div class="section-top col-sm-5 col-lg-5" style="<?php if($datamain[2]==1){
		?>padding-top:0px;padding-left:0px;padding-right:0px;padding-bottom:0px;<?php 
	}?>">
		<div class="topdash-unit" style="overflow: hidden;border-radius: 0px 0px 0px 0px;  background-color: #<?php echo $datamain[4]?>;<?php if($datamain[2]==1){
		?>margin-top:0px;margin-left:0px;margin-right:0px;margin-bottom:0px<?php 
	}else{}?>">
							<div id="myCarousel4" class="carousel slide carousel-fade" data-ride="carousel" >
						<div class="carousel-inner" role="listbox">
							<!--First slide-->
					<?php $dataatas1=mysqli_query($con, "SELECT * FROM `atas` WHERE id = (SELECT MIN(id) FROM `atas`)") or die(mysql_error());  
								while ($atas1=mysqli_fetch_array($dataatas1)){?>		
							<div class="active item" data-interval="5000">
								<img style="width:100%;height:100%;background-size:100% 100%;"  src="konfigurasi/gambar/slide-atas/<?php echo $atas1[2]?>">
							</div>
					<?php } ?>
					<?php $dataatas2=mysqli_query($con, "SELECT * FROM `atas` WHERE id != (SELECT MIN(id) FROM `atas`)") or die(mysql_error());  
								while ($atas2=mysqli_fetch_array($dataatas2)){?>
							<div class="item" data-interval="5000">
								<img style="width:100%;height:100%;background-size:100% 100%;" src="konfigurasi/gambar/slide-atas/<?php echo $atas2[2]?>">
							</div>
					<?php } ?>
						</div>

					</div>
		</div>
	</div>
	
<!---------- CLOCK --------->
<style class="cp-pen-styles">@import url('https://fonts.googleapis.com/css?family=Lato:400,700');

.calendar-today {

  color: #ffffff;
  font-family: 'Lato', sans serif;
  /**margin: 100px auto;
   padding: 10px 20px 50px;
     width: 320px;**/
 
  text-align: center;

}

.month-label { 
  font-size: 35px;
  border-bottom: 2px solid #ffffff;
}

.day-label {
  font-size: 50px;
  line-height: 100%;
  font-weight: 700;

}</style></head><body>
	<div class="section-top  col-sm-4 col-lg-4" style="overflow: hidden;<?php if($datamain[2]==1){
		?>padding-top:0px;padding-left:0px;padding-right:0px;padding-bottom:0px;<?php }?>">
		<div class="topdash-unit" style="background-color: #<?php echo $datamain[4]?>;<?php if($datamain[2]==1){
		?>margin-top:0px;margin-left:0px;margin-right:0px;margin-bottom:0px<?php }else{}?>">
			<div class="col-sm-3 calendar-today">
			  <div class="month-label"></div>
			  <div class="day-label"></div>
			  <div class="weekday-label"></div>
			</div>
<div class="col-sm9 clock" style="center"></div>

		</div>
	</div>	

	
	<div class="section-side  col-sm-2 col-lg-2" style="<?php if($datamain[2]==1){
		?>padding-top:0px;padding-left:0px;padding-right:0px;padding-bottom:0px;<?php 
	}?>">

			<!-- LOCAL TIME BLOCK -->
		<div class="sidedash-unit" style="overflow: hidden;background-color: #<?php echo $datamain[4]?>;<?php if($datamain[2]==1){		?>margin-top:0px;margin-left:0px;margin-right:0px;margin-bottom:0px;height:290px<?php 	}else{}?>">
			<div>
				<div id="myCarousel2" class="carousel slide carousel-fade" data-ride="carousel" >
					<div class="carousel-inner" role="listbox">
						<!--First slide-->
				<?php $datakiriatas1=mysqli_query($con, "SELECT * FROM `kiri_atas` WHERE id = (SELECT MIN(id) FROM `kiri_atas`)") or die(mysql_error());  
							while ($kiri_atas1=mysqli_fetch_array($datakiriatas1)){?>		
						<div class="active item" data-interval="5000">
							<img style="width:100%;height:100%;background-size:100% 100%;" src="konfigurasi/gambar/slide-kiri-atas/<?php echo $kiri_atas1[2]?>">
						</div>
				<?php } ?>		
				<?php $datakiriatas2=mysqli_query($con, "SELECT * FROM `kiri_atas` WHERE id != (SELECT MIN(id) FROM `kiri_atas`)") or die(mysql_error());  
							while ($kiri_atas2=mysqli_fetch_array($datakiriatas2)){?>
						<div class="item" data-interval="5000">
							<img style="width:100%;height:100%;background-size:100% 100%;" src="konfigurasi/gambar/slide-kiri-atas/<?php echo $kiri_atas2[2]?>">
						</div>
				<?php } ?>
					</div>

				</div>
			<!--/.Carousel Wrapper-->
			</div>
		</div>
		<div class="sidedash-unit" style="overflow: hidden;background-color: #<?php echo $datamain[4]?>;<?php if($datamain[2]==1){ ?>margin-top:0px;margin-left:0px;margin-right:0px;margin-bottom:0px;height:290px<?php }else{}?>">
			<div>
				<div id="myCarousel3" class="carousel slide carousel-fade" data-ride="carousel" >
					<div class="carousel-inner" role="listbox">
						<!--First slide-->
				<?php $datakiribawah1=mysqli_query($con, "SELECT * FROM `kiri_bawah` WHERE id = (SELECT MIN(id) FROM `kiri_bawah`)") or die(mysql_error());  
							while ($kiri_bawah1=mysqli_fetch_array($datakiribawah1)){?>		
						<div class="active item" data-interval="5000">
							<img style="width:100%;height:100%;background-size:100% 100%;"  src="konfigurasi/gambar/slide-kiri-bawah/<?php echo $kiri_bawah1[2]?>">
						</div>
				<?php } ?>
				<?php $datakiribawah2=mysqli_query($con, "SELECT * FROM `kiri_bawah` WHERE id != (SELECT MIN(id) FROM `kiri_bawah`)") or die(mysql_error());  
							while ($kiri_bawah2=mysqli_fetch_array($datakiribawah2)){?>
						<div class="item" data-interval="5000">
							<img style="width:100%;height:100%;background-size:100% 100%;" src="konfigurasi/gambar/slide-kiri-bawah/<?php echo $kiri_bawah2[2]?>">
						</div>
				<?php } ?>
					</div>

				</div>
			<!--/.Carousel Wrapper-->
			</div>
				
		</div>
	</div>
	<link rel="stylesheet" href="style_slider.css">
	<script src="js/jquery.anythingslider.js"></script>
	<script src="js/jquery.easing.1.2.js"></script>

	<script>
		// DOM Ready
		$(function(){
			$('#slider').anythingSlider({
				easing: 'easeInOutSine',
				animationTime: 1000,
    			buildArrows         : false,      // If true, builds the forwards and backwards buttons
    			buildNavigation     : false,      // If true, builds a list of anchor links to link to each panel
    			buildStartStop      : false,      // If true, builds the start/stop button and adds slideshow functionality
    			// play the video on the first slide
    			onInitialized: function(e, slider) {
    				var vid = slider.$currentPage.find('video');
    				if (vid.length && typeof(vid[0].pause) !== 'undefined') {
    					vid[0].play();
    					vid[0].onplay = poll(vid);
    				}
    			},
    			// start video again
    			onSlideComplete: function(slider) {
    				var vid = slider.$currentPage.find('video');
    				if (vid.length && typeof(vid[0].pause) !== 'undefined') {
    					vid[0].play();
    					vid[0].onplay = poll(vid);

    				}
    				//Reset time of prev video (now that it's out of view)
    				var prevVid = slider.$lastPage.find('video');
    				if (prevVid.length && typeof(prevVid[0].pause) !== 'undefined') {
    					prevVid[0].currentTime = 0;
    				}
    			},
    		});
			//Add the event listener to the current video
			function poll(vid) {
				vid[0].addEventListener('ended', vidEnded,false);
				function vidEnded(e) {
					if(!e) { e = window.event; }
					$('#slider').data('AnythingSlider').goForward();
				}
			}
		});
	</script>
	
<div style="align-items:center; justify-content:center; overflow: hidden;<?php if($datamain[2]==1){	?>padding-top:0px;padding-left:0px;padding-right:0px;padding-bottom:0px;<?php }?>" class="col-sm-8 col-lg-8" >
	<ul id="slider">
	<?php $dataslideutama=mysqli_query($con, "SELECT * FROM `slider`") or die(mysql_error());
	$i=0;
	while ($slide_utama=mysqli_fetch_array($dataslideutama)){
		$i+=1;?>
	<li class="panel<?php $i;?>">
		<video style=" object-fit: fill;height:50%;">
			<source src="./konfigurasi/gambar/slide-utama/<?php echo $slide_utama[2];?>" type="video/mp4">
		</video>
	</li>
	<?php }?>

	</ul>			
</div>

  <style>
  <style>
.agenda {  }

/* Dates */
.agenda .agenda-date { width: 170px; }
.agenda .agenda-date .dayofmonth {
  width: 40px;
  font-size: 36px;
  line-height: 36px;
  float: left;
  text-align: right;
  margin-right: 10px; 
}
.agenda .agenda-date .shortdate {
  font-size: 0.75em; 
}


/* Times */
.agenda .agenda-time { width: 140px; } 


/* Events */
.agenda .agenda-events {  } 
.agenda .agenda-events .agenda-event {  } 

@media (max-width: 767px) {
    
}
</style>
  </style>
    <div class="section-side col-sm-2 col-lg-2" style="<?php if($datamain[2]==1){	?>padding-top:0px;padding-left:0px;padding-right:0px;padding-bottom:0px;<?php }?>">
     	<div class="sidedash-unit" style="background-color: #<?php echo $datamain[4]?>;<?php if($datamain[2]==1){	?>margin-top:0px;margin-left:0px;margin-right:0px;margin-bottom:0px;height:290px<?php }else{}?>">
	      	<dtitle style="color:#<?php echo $datamain[6];?>">Agenda</dtitle>
	      	<hr>
			<div class="agenda">
        <div class="table-responsive">
            <table class="table table-condensed table-bordered">
                
				<tbody>
				<?php $now = date("d");
				$day5=$now + 11;
				$no=0;
				$query = mysqli_query($con, "SELECT * FROM agenda ORDER by jadwal_mulai");
				while ($row = mysqli_fetch_array($query)) {

					if($row['bulan_mulai']==1){
						$bulan = "Januari";
					}else if($row['bulan_mulai']==2){
						$bulan = "Februari";
					}else if($row['bulan_mulai']==3){
						$bulan = "Maret";
					}else if($row['bulan_mulai']==4){
						$bulan = "April";
					}else if($row['bulan_mulai']==5){
						$bulan = "Mai";
					}else if($row['bulan_mulai']==6){
						$bulan = "Juni";
					}else if($row['bulan_mulai']==7){
						$bulan = "Juli";
					}else if($row['bulan_mulai']==8){
						$bulan = "Agustus";
					}else if($row['bulan_mulai']==9){
						$bulan = "September";
					}else if($row['bulan_mulai']==10){
						$bulan = "Oktober";
					}else if($row['bulan_mulai']==11){
						$bulan = "September";
					}else if($row['bulan_mulai']==12){
						$bulan = "Desember";
						}
						
					$data[$no]['tanggal_mulai'] = $row['tanggal_mulai'];
					$data[$no]['jadwal_mulai'] = $row['jadwal_mulai'];
					$data[$no]['hari_mulai'] = $row['hari_mulai'];
					$data[$no]['tahun_mulai'] = $row['tahun_mulai'];
					$data[$no]['jam_mulai'] = $row['jam_mulai'];
					$data[$no]['menit_mulai'] = $row['menit_mulai'];			
					$data[$no]['jam_selesai'] = $row['jam_selesai'];
					$data[$no]['menit_selesai'] = $row['menit_selesai'];
					$data[$no]['agenda'] = $row['agenda'];
					$data[$no]['bulan'] = $bulan;
					
					$no = $no + 1;
					?>
					
					
			
                
					<tr>
						<td class=""  class="active" rowspan="<?php echo $cn[$row['jadwal_mulai']];?>">
							<div style="font-size:14px" class="dayofmonth"><?php echo "".$row['hari_mulai'].", ".$row['tanggal_mulai']." ".$bulan." ".$row['tahun_mulai']."";?>
								&nbsp&nbsp&nbsp<?php echo "".$row['jam_mulai'].":".$row['menit_mulai']." - ".$row['jam_selesai'].":".$row['menit_selesai']."";?>
								</div>
								<br><div style="font-size:18px"><b><?php echo $row['agenda'];?></b></div>
						</td>
						
						
					</tr>
                    		<?php
				
				}
				?>
                </tbody>
            </table>
        </div>
    </div>
			<div>
			
			</div>
		</div>

			<!-- SERVER UPTIME -->
		<div class="sidedash-unit" style="overflow: hidden;background-color: #<?php echo $datamain[4]?>;<?php if($datamain[2]==1){	?>margin-top:0px;margin-left:0px;margin-right:0px;margin-bottom:0px;height:290px<?php }else{}?>">
	      	<div>
				<div id="myCarousel5" class="carousel slide carousel-fade" data-ride="carousel" >
					<div class="carousel-inner" role="listbox">
						<!--First slide-->
				<?php $datakananbawah1=mysqli_query($con, "SELECT * FROM `kanan_bawah` WHERE id = (SELECT MIN(id) FROM `kanan_bawah`)") or die(mysql_error());  
							while ($kanan_bawah1=mysqli_fetch_array($datakananbawah1)){?>		
						<div class="active item" data-interval="5000">
							<img style="width:100%;height:100%;background-size:100% 100%;" src="konfigurasi/gambar/slide-kanan-bawah/<?php echo $kanan_bawah1[2]?>">
						</div>
				<?php } ?>		
				<?php $datakananbawah2=mysqli_query($con, "SELECT * FROM `kanan_bawah` WHERE id != (SELECT MIN(id) FROM `kanan_bawah`)") or die(mysql_error());  
							while ($kanan_bawah2=mysqli_fetch_array($datakananbawah2)){?>
						<div class="item" data-interval="5000">
							<img style="width:100%;height:100%;background-size:100% 100%;" src="konfigurasi/gambar/slide-kanan-bawah/<?php echo $kanan_bawah2[2]?>">
						</div>
				<?php } ?>
					</div>

				</div>
			<!--/.Carousel Wrapper-->
			</div>
		</div>

    </div>

	<div class="section-bot col-sm-12 col-lg-12" style="<?php if($datamain[2]==1){	?>padding-top:0px;padding-left:0px;padding-right:0px;padding-bottom:0px;<?php }?>">
	
		<div class="footdash-unit" style="border-radius: 0px 0px 0px 0px;overflow: hidden;background-color: #<?php echo $datamain[4]?>;<?php if($datamain[2]==1){	?>margin-top:0px;margin-left:0px;margin-right:0px;margin-bottom:0px;<?php }else{}?>">
			<?php
				$bodytext = mysqli_fetch_array(mysqli_query($con, "SELECT * FROM `beritagabung`ORDER BY ID DESC LIMIT 1"));
				$jeda = mysqli_fetch_array(mysqli_query($con, "SELECT * FROM `konfigurasi`"));
			?>
			<center><marquee style="font-size:55px;"><?php echo $bodytext[1]; ?></marquee></center>
		</div>
	</div>
	<div id="cek">
	
    </div>

    <script>
        setInterval(
            function()
            {
                $('#cek').load('cek.php');
                // var nilai = <?php $pilihan = mysqli_fetch_array(mysqli_query($con, "SELECT * FROM `konfigurasi`"));
                // echo $pilihan['refresh']; ?>;
                // if (nilai==1){
                //     window.location.href="index.php";
                //  }
            },
        500);
    </script>
</div>

 <!------------------ FLIP CLOCK -->
		<script type="text/javascript">
			var clock;
			
			$(document).ready(function() {
				clock = $('.clock').FlipClock({
					clockFace: 'TwentyFourHourClock',
					showSeconds: false
				});
			});
		</script>
	
	<!-- NOTY JAVASCRIPT -->
	<script type="text/javascript" src="assets/js/noty/jquery.noty.js"></script>
	<script type="text/javascript" src="assets/js/noty/layouts/top.js"></script>
	<script type="text/javascript" src="assets/js/noty/layouts/topLeft.js"></script>
	<script type="text/javascript" src="assets/js/noty/layouts/topRight.js"></script>
	<script type="text/javascript" src="assets/js/noty/layouts/topCenter.js"></script>
	
	<!-- You can add more layouts if you want -->
	<script type="text/javascript" src="assets/js/noty/themes/default.js"></script>
    <!-- <script type="text/javascript" src="assets/js/dash-noty.js"></script> This is a Noty bubble when you init the theme-->

	<script src="assets/js/jquery.flexslider.js" type="text/javascript"></script>
	<script src="assets/js/moment.min.js"></script>
	<script src="assets/js/script.js"></script>
	
	<script>
	$(document).ready(function() {
	  var interval = setInterval(function() {
		var momentNow = moment().locale("id");
		$("#date-part").html(momentNow.format("DD "));
		$("#day-part").html(
		  momentNow
			.format("dddd")
			.substring(0, 3)
			.toUpperCase()
			
		);

		$("#month-part").html(momentNow.format("DD MMMM"));
	  }, 100);
	});
	</script>
  
  <script >var date = new Date();
var day = date.getDate();
var month = date.getMonth()+1;
var year = date.getFullYear();
var monthNames = ["Januari", "Februari", "Maret", "April", "Mai", "Juni", "Juli", "Agustus", "September", "Oktober", "Nopember", "Desember"];
var dayNames = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jum'at", "Sabtu"];

var monthLabel = document.getElementsByClassName("month-label")[0].innerHTML = monthNames[date.getMonth()];

var dayLabel = document.getElementsByClassName("day-label")[0].innerHTML = day;

var weekdayLabel = document.getElementsByClassName("weekday-label")[0].innerHTML = dayNames[date.getDay(0)];

</script>
  <!--Carousel Wrapper-->
                        
    <!-- /Start your project here-->

    <!-- SCRIPTS -->
    <!-- JQuery -->

    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="js/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
   
    <!-- MDB core JavaScript -->
 
</body></html>
